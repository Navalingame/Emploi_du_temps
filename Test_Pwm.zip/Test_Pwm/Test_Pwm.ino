//------------------------------------------------------------------------------------
// Test_Pwm.c
// 
//------------------------------------------------------------------------------------

#include    "Tiva_TM4C123.h"


#define PIN_LED     PF_3
#define PIN_MT1     PA_5
#define PIN_MT2     PB_0

int counter, vled;

void setup() 
//----------------------------------------------------
//----------------------------------------------------
{
  Serial.begin(9600);
  pinMode(PIN_LED, OUTPUT);
  pinMode(PIN_MT1, INPUT);
  pinMode(PIN_MT2, INPUT);

  delay(2000);
  Serial.println("+++ INIT  Debut");
  Motor_Pwm_Init();
  Serial.println("+++ INIT  Fin  ++++");

  Motor_Pwm_Action(MOTOR_STOP);
  delay(1000);
  counter = 0;      vled = 0;
}

      
void loop() 
//----------------------------------------------------
//----------------------------------------------------
{
 

      Motor_Pwm_Action(MOTOR_AVANCER);
      delay(1000);
      Motor_Pwm_Action(MOTOR_RECULER);
      delay(1000);
      Motor_Pwm_Action(MOTOR_AVANT_G);
      Motor_Pwm_Action(MOTOR_RECUL_D);  
      delay(1000);
      Motor_Pwm_Action(MOTOR_AVANCER);
      delay(1000);
      Motor_Pwm_Action(MOTOR_RECUL_G);
      Motor_Pwm_Action(MOTOR_AVANT_D);
      delay(1000);
      
}
