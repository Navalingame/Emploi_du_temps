//------------------------------------------------------------------------------------
// Gnn_Projet_ECG.c
// 
//------------------------------------------------------------------------------------

#include    "Gnx_Project_ECG.h"
#include    "OLedAffi_MyLogo.h"


void setup()
//----------------------------------------------------
//----------------------------------------------------
{
    Serial.begin(9600);
    pinMode(PIN_LED_R,  OUTPUT);
    pinMode(PIN_LED_G,  OUTPUT);
    pinMode(PIN_LED_B,  OUTPUT);
    pinMode(PIN_POTAR,  INPUT);
    pinMode(PIN_BOUTON, INPUT);

    Sensor_Init();
    AOLED_InitScreen();
    delay(500);
    AOLED_AffiLogoIsep();
    //AOLED_DisplayImage((char*)Gnn_myLogo);
    
    digitalWrite(PIN_LED_R, LOW);
    digitalWrite(PIN_LED_B, LOW);
    digitalWrite(PIN_LED_G, HIGH);
}

void loop()
//----------------------------------------------------
//----------------------------------------------------
{    short valpotar, etat, nbtr;

    etat = digitalRead(PIN_BOUTON);
    if (etat == 0) {        // bouton appuyé
        while (1) {
            etat = digitalRead(PIN_BOUTON);
            if (etat == 1)  // attendre que le bouton soit relaché
                break;
        }
        Sensor_Measure();
   }
    
    valpotar = analogRead(PIN_POTAR);
sortie:
    delay(500);
}
